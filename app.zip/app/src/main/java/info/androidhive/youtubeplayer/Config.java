package info.androidhive.youtubeplayer;

public class Config {
	// Google Console APIs developer key
	// Replace this key with your's
	public static final String DEVELOPER_KEY = "AIzaSyA60BDL4qE5zPlej1Wq1jcrpcpaD5hl1us";
	
	// YouTube video id
	public static final String YOUTUBE_VIDEO_CODE = "_oEA18Y8gM0";
}
